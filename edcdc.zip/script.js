'use strict';

// prettier-ignore
const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const form = document.querySelector('.form');
const containerWorkouts = document.querySelector('.workouts');
const inputType = document.querySelector('.form__input--type');
const inputDistance = document.querySelector('.form__input--distance');
const inputDuration = document.querySelector('.form__input--duration');
const inputCadence = document.querySelector('.form__input--cadence');
const inputElevation = document.querySelector('.form__input--elevation');
let map;
let startCoords;
let endCoords;
let markerEnd;
let markerStart;
let a = 0;

class Workout {
  date = new Date();
  id = (Date.now() + '').slice(-8);
  constructor(speed, startCoords, endCoords) {
    this.speed = speed;
    this.startCoords = startCoords;
    this.endCoords = endCoords;
  }
}

class App {
  constructor() {
    this.openMap();
    window.addEventListener('keydown', this.showForm.bind(this));
  }
  openMap() {
    navigator.geolocation.getCurrentPosition(
      this.showMap.bind(this),
      function () {
        alert('geolokatsiya ola olmadik. Qayta urinib kurin');
      }
    );
  }
  showMap(e) {
    map = L.map('map').setView([e.coords.latitude, e.coords.longitude], 15);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(
      map
    );

    markerStart = L.marker([e.coords.latitude, e.coords.longitude], {
      draggable: true,
    })
      .addTo(map)
      .bindPopup('A pretty CSS3 popup.<br> Easily customizable.')
      .openPopup();
  }
  showForm() {
    a++;
    if (!(a == 1 || a == 2)) return;
    if (a == 1) {
      startCoords = markerStart.getLatLng();
      map.removeLayer(markerStart);
      let startMarker = L.marker([startCoords.lat, startCoords.lng], {
        draggable: false,
      })
        .addTo(map)
        .bindPopup('A pretty CSS3 popup.<br> Easily customizable.')
        .openPopup();

      markerEnd = L.marker([startCoords.lat + 0.01, startCoords.lng + 0.01], {
        draggable: true,
      })
        .addTo(map)
        .bindPopup('A pretty CSS3 popup.<br> Easily customizable.')
        .openPopup();
    }
    if (a == 2) {
      endCoords = markerEnd.getLatLng();
      map.removeLayer(markerEnd);
      let endMarker = L.marker([endCoords.lat, endCoords.lng], {
        draggable: false,
      })
        .addTo(map)
        .bindPopup('A pretty CSS3 popup.<br> Easily customizable.')
        .openPopup();
      form.classList.remove('hidden');
      // inputDistance.focus();
      this.hiddenForm();
    }
  }
  hiddenForm() {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      let speed = inputDistance.value;
      form.classList.add('hidden');
    });
  }
  drawMap() {}
}

const magicMap = new App();
